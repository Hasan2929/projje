<?php
// === استدعاء ملفات الإعلانات المحلية ===

// السكريبت الخاص بـ Native Banner
echo '<script async="async" data-cfasync="false" src="js/ads/native.js"></script>';

// إعلان Popunder
echo '<script type="text/javascript" src="js/ads/popunder.js"></script>';

// إعلان Social Bar
echo '<script type="text/javascript" src="js/ads/social.js"></script>';
?>